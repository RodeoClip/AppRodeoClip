
import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { UploadZone } from './components/UploadZone';
import { VideoPreview } from './components/VideoPreview';
import { ConversionControls } from './components/ConversionControls';
import { ProcessingModal } from './components/ProcessingModal';
import { ProcessingStatus } from './types';
import { ArrowRight, Video } from 'lucide-react';

const RodeoClipApp: React.FC = () => {
  const { state, dispatch } = useApp();

  const handleDownloadClick = () => {
    if (state.files.length === 0) return;
    
    // Check auth status
    if (state.session.isAuthenticated && state.session.subscriptionStatus === 'active') {
      dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.PAID });
    } else {
      dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.READY_TO_PAY });
    }
  };

  return (
    <div className="min-h-screen bg-[#1a1818] text-gray-100 flex flex-col font-sans selection:bg-rodeo-500 selection:text-black">
      
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#1a1818]/95 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-rodeo-500 p-1.5 rounded-lg">
              <Video className="w-5 h-5 text-black" />
            </div>
            <h1 className="text-2xl font-brand text-white tracking-wide">
              Rodeo<span className="text-rodeo-500">Clip</span>
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-gray-500 hidden md:block">Next Gen Rodeo Converter</span>
            {state.session.isAuthenticated && (
              <span className="text-xs bg-green-900/50 text-green-400 px-2 py-1 rounded border border-green-800">
                PRO LICENSE ACTIVE
              </span>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-8 md:px-6 md:py-8 flex flex-col md:flex-row gap-6 h-[calc(100vh-4rem)]">
        
        {/* Left Column: Upload & Settings */}
        <div className="w-full md:w-1/3 flex flex-col gap-6">
          <UploadZone />
          <div className="flex-1 min-h-0">
            <ConversionControls />
          </div>
        </div>

        {/* Right Column: Preview & Actions */}
        <div className="w-full md:w-2/3 bg-gray-900/30 rounded-2xl border border-gray-800 p-6 flex flex-col relative">
          
          <div className="flex-1 flex items-center justify-center min-h-0 overflow-hidden">
             <VideoPreview />
          </div>

          <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Spacer for alignment */}
            <div className="flex-1"></div>

            <button 
              onClick={handleDownloadClick}
              disabled={state.files.length === 0}
              className={`
                group px-8 py-4 rounded-xl font-bold text-lg flex items-center gap-2 transition-all shadow-lg shadow-rodeo-900/50
                ${state.files.length === 0 
                  ? 'bg-gray-800 text-gray-500 cursor-not-allowed' 
                  : 'bg-rodeo-500 text-black hover:bg-rodeo-400 hover:scale-[1.02] active:scale-95'
                }
              `}
            >
              Export Final
              <ArrowRight className={`w-5 h-5 transition-transform ${state.files.length > 0 ? 'group-hover:translate-x-1' : ''}`} />
            </button>
          </div>

        </div>
      </main>

      <ProcessingModal />
    </div>
  );
};

// Wrap with Provider
const App: React.FC = () => {
  return (
    <AppProvider>
      <RodeoClipApp />
    </AppProvider>
  );
};

export default App;
