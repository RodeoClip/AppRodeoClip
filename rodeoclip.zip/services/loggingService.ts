import { LogEvent } from '../types';

class LoggingService {
  private queue: LogEvent[] = [];

  log(event: string, data?: Record<string, any>) {
    const logEntry: LogEvent = {
      event,
      timestamp: Date.now(),
      data,
    };
    
    this.queue.push(logEntry);
    
    // Simulate sending to PostHog/Supabase
    console.groupCollapsed(`[Analytics] ${event}`);
    console.log(data);
    console.groupEnd();
  }

  // Simulate flushing logs to backend
  async flush() {
    if (this.queue.length === 0) return;
    const batch = [...this.queue];
    this.queue = [];
    
    // In real app: await fetch('/api/logs', { body: JSON.stringify(batch) ... })
    console.log(`Flushed ${batch.length} logs to server.`);
  }
}

export const logger = new LoggingService();