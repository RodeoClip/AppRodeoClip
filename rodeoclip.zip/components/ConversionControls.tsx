
import React from 'react';
import { useApp } from '../context/AppContext';
import { Sliders, Image as ImageIcon, Zap, Trash2, RotateCw } from 'lucide-react';
import { logger } from '../services/loggingService';

export const ConversionControls: React.FC = () => {
  const { state, dispatch } = useApp();
  const { settings, files, activeFileId } = state;

  const handleSpeedChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch({ type: 'UPDATE_SETTINGS', payload: { speed: parseFloat(e.target.value) } });
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      
      // Cleanup old URL
      if (settings.logoUrl) URL.revokeObjectURL(settings.logoUrl);
      
      dispatch({ type: 'UPDATE_SETTINGS', payload: { logo: file, logoUrl: url } });
      logger.log('logo_uploaded');
    }
  };

  const toggleRotation = () => {
    const newRotation = settings.rotation === 0 ? 90 : 0;
    dispatch({ type: 'UPDATE_SETTINGS', payload: { rotation: newRotation } });
  };

  return (
    <div className="bg-gray-900/50 p-6 rounded-xl border border-gray-800 space-y-8 h-full">
      
      {/* File List */}
      <div>
        <h3 className="text-rodeo-400 font-brand text-xl mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5" />
          Queue ({files.length})
        </h3>
        <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
          {files.map(file => (
            <div 
              key={file.id}
              onClick={() => dispatch({ type: 'SET_ACTIVE_FILE', payload: file.id })}
              className={`p-3 rounded-lg flex justify-between items-center cursor-pointer transition-colors ${
                activeFileId === file.id 
                  ? 'bg-rodeo-900 border border-rodeo-500/50' 
                  : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              <div className="truncate text-sm text-gray-200 max-w-[70%]">
                {file.file.name}
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  dispatch({ type: 'REMOVE_FILE', payload: file.id });
                }}
                className="text-gray-500 hover:text-red-400"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
          {files.length === 0 && (
            <div className="text-gray-500 text-sm italic">No videos queued.</div>
          )}
        </div>
      </div>

      <hr className="border-gray-800" />

      {/* Speed Control */}
      <div>
        <label className="flex items-center gap-2 text-white font-medium mb-3">
          <Sliders className="w-4 h-4 text-rodeo-500" />
          Playback Speed
        </label>
        <div className="flex items-center gap-4">
          <input 
            type="range" 
            min="0.1" 
            max="2.0" 
            step="0.1"
            value={settings.speed} 
            onChange={handleSpeedChange}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-rodeo-500"
          />
          <span className="text-rodeo-400 font-mono w-12 text-right">{settings.speed}x</span>
        </div>
      </div>

      {/* Rotation Control */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="flex items-center gap-2 text-white font-medium">
            <RotateCw className="w-4 h-4 text-rodeo-500" />
            Rotate 90° (Verticalize)
          </label>
          <button 
            onClick={toggleRotation}
            className={`w-12 h-6 rounded-full transition-colors relative focus:outline-none ${settings.rotation === 90 ? 'bg-rodeo-500' : 'bg-gray-700'}`}
          >
            <div className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full transition-transform duration-200 ${settings.rotation === 90 ? 'translate-x-6' : 'translate-x-0'}`} />
          </button>
        </div>
        <p className="text-xs text-gray-500">Perfect for turning horizontal action shots into vertical clips.</p>
      </div>

      {/* Logo Upload */}
      <div>
        <label className="flex items-center gap-2 text-white font-medium mb-3">
          <ImageIcon className="w-4 h-4 text-rodeo-500" />
          Branding Logo
        </label>
        <div className="flex items-start gap-4">
          <div className="flex-1">
             <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-gray-700 border-dashed rounded-lg cursor-pointer bg-gray-800 hover:bg-gray-700">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <p className="text-xs text-gray-400">PNG / Transparent</p>
                </div>
                <input type="file" className="hidden" accept="image/png" onChange={handleLogoUpload} />
            </label>
          </div>
          {settings.logoUrl && (
            <div className="w-24 h-24 bg-black/50 rounded-lg border border-gray-700 flex items-center justify-center p-2 relative group">
              <img src={settings.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain" />
              <button 
                onClick={() => dispatch({ type: 'UPDATE_SETTINGS', payload: { logo: null, logoUrl: null } })}
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      </div>

    </div>
  );
};
