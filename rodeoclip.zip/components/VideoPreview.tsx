
import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Loader2, Play } from 'lucide-react';

export const VideoPreview: React.FC = () => {
  const { state } = useApp();
  const { activeFileId, files, settings } = state;
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isReady, setIsReady] = useState(false);

  const activeFile = files.find(f => f.id === activeFileId);

  useEffect(() => {
    if (videoRef.current) {
      // Apply speed setting directly to video element
      videoRef.current.playbackRate = settings.speed;
    }
  }, [settings.speed, activeFileId]);

  useEffect(() => {
    setIsReady(false);
    setIsPlaying(false);
  }, [activeFileId]);

  if (!activeFile) {
    return (
      <div className="h-full w-full flex items-center justify-center border-4 border-dashed border-[#5b8cff] rounded-xl bg-black/20">
        <div className="text-center">
          <p className="text-lg font-medium text-[#5b8cff]">Select a video to preview</p>
        </div>
      </div>
    );
  }

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="relative flex flex-col items-center h-full justify-center">
      {/* 
        This container simulates the 9:16 Crop visually with a dashed border
      */}
      <div 
        className="relative bg-black rounded-lg overflow-hidden shadow-2xl border-4 border-dashed border-[#5b8cff]"
        style={{ 
          aspectRatio: '9/16', 
          height: '600px', // Fixed height for UI
          maxWidth: '100%'
        }}
      >
        {!isReady && (
          <div className="absolute inset-0 z-20 flex items-center justify-center bg-gray-900">
            <Loader2 className="w-8 h-8 text-rodeo-500 animate-spin" />
          </div>
        )}

        {/* The Video Element */}
        <video
          ref={videoRef}
          src={activeFile.previewUrl || ""}
          className="w-full h-full" 
          style={{
            // When rotated 90deg, a 16:9 video needs to fit a 9:16 container.
            // Using 'contain' keeps the full video visible, but small. 
            // We then scale it up by 1.7778 (16/9) so the rotated width (original height) fills the container width.
            objectFit: settings.rotation === 90 ? 'contain' : 'cover',
            transform: settings.rotation === 90 ? 'rotate(90deg) scale(1.7778)' : 'none',
            transition: 'transform 0.3s ease, object-fit 0.3s ease'
          }}
          playsInline
          loop
          muted={false}
          onLoadedData={() => setIsReady(true)}
          onEnded={() => setIsPlaying(false)}
        />

        {/* Logo Overlay Simulation */}
        {settings.logoUrl && (
          <div className="absolute top-8 right-8 z-10 w-20 h-20 pointer-events-none opacity-90">
            <img src={settings.logoUrl} alt="Watermark" className="w-full h-full object-contain" />
          </div>
        )}

        {/* Play Controls Overlay */}
        <div 
          className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/10 transition-colors cursor-pointer"
          onClick={togglePlay}
        >
          {!isPlaying && isReady && (
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/50">
              <Play className="w-8 h-8 text-white fill-white ml-1" />
            </div>
          )}
        </div>
      </div>

      <div className="mt-4 text-center text-sm text-gray-400">
        <p className="font-mono">{activeFile.file.name}</p>
        <p className="text-xs text-gray-500 mt-1">
          {(activeFile.size / (1024 * 1024)).toFixed(1)} MB • Speed: {settings.speed}x • Rotation: {settings.rotation}°
        </p>
      </div>
    </div>
  );
};
