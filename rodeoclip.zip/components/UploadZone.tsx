
import React, { useCallback, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { VideoFile } from '../types';
import { storeFile } from '../services/storageService';
import { MAX_FILE_SIZE } from '../constants';
import { logger } from '../services/loggingService';
import { FolderUp, FileVideo } from 'lucide-react';

export const UploadZone: React.FC = () => {
  const { dispatch } = useApp();
  const inputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const processFiles = async (fileList: FileList | null) => {
    if (!fileList) return;

    const validFiles: VideoFile[] = [];
    const ArrayFiles = Array.from(fileList);

    logger.log('upload_attempt', { count: ArrayFiles.length });

    for (const file of ArrayFiles) {
      if (file.size > MAX_FILE_SIZE) {
        alert(`File ${file.name} is too large. Max 5GB.`);
        continue;
      }
      
      // Basic mime check - normally would check magic bytes
      if (!file.type.startsWith('video/')) {
        continue;
      }

      const id = crypto.randomUUID();
      
      // Store in IndexedDB (don't block UI)
      storeFile(id, file).catch(err => console.error("Storage failed", err));

      // Create temp blob for preview
      const previewUrl = URL.createObjectURL(file);

      validFiles.push({
        id,
        file,
        previewUrl,
        duration: 0, // Would be extracted via loadedmetadata
        format: file.type,
        size: file.size
      });
    }

    if (validFiles.length > 0) {
      dispatch({ type: 'ADD_FILES', payload: validFiles });
      dispatch({ type: 'SET_ACTIVE_FILE', payload: validFiles[0].id });
      
      // Force rotation to 90 (Vertical) automatically on every upload
      // This ensures the "Verticalize" function is applied without manual selection
      dispatch({ type: 'UPDATE_SETTINGS', payload: { rotation: 90 } });
      
      logger.log('upload_success', { count: validFiles.length });
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    processFiles(e.dataTransfer.files);
  }, []);

  return (
    <div 
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
      className="border-2 border-dashed border-rodeo-500/50 bg-rodeo-800/30 rounded-xl p-8 text-center transition-all hover:bg-rodeo-800/50 hover:border-rodeo-500 cursor-default group"
    >
      <div className="flex flex-col items-center gap-4">
        
        <div className="w-full">
          <h3 className="text-xl font-bold text-white mb-2">Drop your Rodeo footage here</h3>
          <p className="text-gray-400 text-sm mb-6">Supports MP4, MOV, MXF (Max 5GB/file)</p>
          
          <div className="flex gap-4 justify-center w-full">
            <button 
              onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }}
              className="px-8 py-5 bg-[#e87f15] hover:bg-[#ff9933] border-b-4 border-[#a65608] active:border-b-0 active:translate-y-1 text-white font-bold rounded-lg shadow-xl transition-all flex flex-col items-center justify-center gap-2 min-w-[140px]"
            >
              <FileVideo className="w-8 h-8 mb-1" />
              <span>Select Files</span>
            </button>
            
            <button 
              onClick={(e) => { e.stopPropagation(); folderInputRef.current?.click(); }}
              className="px-8 py-5 bg-[#333a4d] hover:bg-[#434c63] border-b-4 border-[#1e222e] active:border-b-0 active:translate-y-1 text-white font-bold rounded-lg shadow-xl transition-all flex flex-col items-center justify-center gap-2 min-w-[140px]"
            >
              <FolderUp className="w-8 h-8 mb-1" />
              <span>Select Folder</span>
            </button>
          </div>
        </div>
      </div>

      <input 
        ref={inputRef}
        type="file" 
        multiple 
        accept="video/*" 
        className="hidden" 
        onChange={(e) => processFiles(e.target.files)}
      />
      <input 
        ref={folderInputRef}
        type="file" 
        // @ts-ignore
        webkitdirectory=""
        directory=""
        multiple
        className="hidden" 
        onChange={(e) => processFiles(e.target.files)}
      />
    </div>
  );
};
