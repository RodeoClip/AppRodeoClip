import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProcessingStatus } from '../types';
import { api } from '../services/apiService';
import { CheckCircle, Lock, Download, Loader, CreditCard, XCircle } from 'lucide-react';
import { PRICE_MONTHLY } from '../constants';

export const ProcessingModal: React.FC = () => {
  const { state, dispatch } = useApp();
  const { status, session } = state;
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  if (status === ProcessingStatus.IDLE || status === ProcessingStatus.PREVIEW_GENERATING) return null;

  const handleCheckout = async () => {
    try {
      const { checkoutUrl, sessionId } = await api.checkout();
      // Simulate going to Stripe
      console.log(`Redirecting to ${checkoutUrl}...`);
      
      // Simulate Success Return
      const userSession = await api.validatePayment(sessionId);
      dispatch({ type: 'SET_SESSION', payload: userSession });
      dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.PAID });
      
    } catch (e) {
      alert("Payment failed simulation");
    }
  };

  const handleProcess = async () => {
    if (!state.activeFileId || !state.session.downloadToken) return;
    
    dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.PROCESSING });
    
    try {
      const result = await api.processVideo(
        state.activeFileId, 
        state.session.downloadToken, 
        state.settings
      );
      setDownloadUrl(result.downloadUrl);
      dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.COMPLETED });
    } catch (e) {
      dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.FAILED });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
      <div className="bg-gray-900 border border-rodeo-500/30 rounded-2xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden">
        
        {/* Decorative header */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-rodeo-500 via-yellow-500 to-rodeo-500"></div>

        <div className="text-center mb-6 mt-4">
          <h2 className="text-2xl font-brand text-white">Finalize RodeoClip</h2>
        </div>

        {/* READY TO PAY / LOCKED */}
        {status === ProcessingStatus.READY_TO_PAY && (
          <div className="space-y-6">
            <div className="bg-gray-800 p-4 rounded-lg flex items-center justify-between">
              <span className="text-gray-300">Monthly Pro License</span>
              <span className="text-xl font-bold text-white">R$ {PRICE_MONTHLY}</span>
            </div>
            
            <ul className="text-sm text-gray-400 space-y-2 text-left pl-4">
              <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500"/> Unlimited conversions</li>
              <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500"/> No watermarks</li>
              <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500"/> Priority processing</li>
            </ul>

            <button 
              onClick={handleCheckout}
              className="w-full py-4 bg-rodeo-500 hover:bg-rodeo-400 text-black font-bold text-lg rounded-xl flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
            >
              <CreditCard className="w-5 h-5" />
              Subscribe & Download
            </button>
          </div>
        )}

        {/* PAID / START PROCESSING */}
        {status === ProcessingStatus.PAID && (
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <h3 className="text-white text-lg">Payment Confirmed!</h3>
            <p className="text-gray-400 text-sm">Your secure download token is ready.</p>
            
            <button 
              onClick={handleProcess}
              className="w-full py-3 bg-white text-black font-bold rounded-lg hover:bg-gray-200 transition-colors"
            >
              Generate Full 1080p Video
            </button>
          </div>
        )}

        {/* PROCESSING */}
        {status === ProcessingStatus.PROCESSING && (
          <div className="text-center space-y-6 py-8">
            <Loader className="w-12 h-12 text-rodeo-500 animate-spin mx-auto" />
            <div className="space-y-2">
              <h3 className="text-white font-medium">Processing your clip...</h3>
              <p className="text-xs text-gray-500">Rendering high quality vertical format.</p>
            </div>
          </div>
        )}

        {/* COMPLETED */}
        {status === ProcessingStatus.COMPLETED && downloadUrl && (
          <div className="text-center space-y-6">
             <div className="w-16 h-16 bg-rodeo-500/20 rounded-full flex items-center justify-center mx-auto">
              <Download className="w-8 h-8 text-rodeo-500" />
            </div>
            <h3 className="text-white font-brand text-xl">Ready for Socials!</h3>
            
            <a 
              href={downloadUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full py-4 bg-rodeo-500 hover:bg-rodeo-400 text-black font-bold rounded-xl transition-all"
            >
              Download MP4
            </a>
            
            <button 
              onClick={() => dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.IDLE })}
              className="text-gray-500 hover:text-white text-sm"
            >
              Process another video
            </button>
          </div>
        )}

        {/* CLOSE BUTTON (Only if not processing) */}
        {status !== ProcessingStatus.PROCESSING && (
          <button 
            onClick={() => dispatch({ type: 'SET_STATUS', payload: ProcessingStatus.IDLE })}
            className="absolute top-4 right-4 text-gray-500 hover:text-white"
          >
            <XCircle className="w-6 h-6" />
          </button>
        )}

      </div>
    </div>
  );
};