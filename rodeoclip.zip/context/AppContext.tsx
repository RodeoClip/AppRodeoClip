
import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { VideoFile, ConversionSettings, UserSession, ProcessingStatus } from '../types';
import { clearStorage } from '../services/storageService';
import { logger } from '../services/loggingService';

interface AppState {
  files: VideoFile[];
  settings: ConversionSettings;
  session: UserSession;
  status: ProcessingStatus;
  activeFileId: string | null;
}

type Action =
  | { type: 'ADD_FILES'; payload: VideoFile[] }
  | { type: 'REMOVE_FILE'; payload: string }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<ConversionSettings> }
  | { type: 'SET_SESSION'; payload: UserSession }
  | { type: 'SET_STATUS'; payload: ProcessingStatus }
  | { type: 'SET_ACTIVE_FILE'; payload: string }
  | { type: 'RESET_APP' };

const initialState: AppState = {
  files: [],
  settings: {
    speed: 1.0,
    logo: null,
    logoUrl: null,
    autoCrop: true,
    outputQuality: '1080p',
    rotation: 90 // Default to 90 (Vertical) automatically
  },
  session: {
    isAuthenticated: false,
    subscriptionStatus: 'none',
    downloadToken: null,
    tokenExpiry: null
  },
  status: ProcessingStatus.IDLE,
  activeFileId: null
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<Action>;
}>({ state: initialState, dispatch: () => null });

const appReducer = (state: AppState, action: Action): AppState => {
  switch (action.type) {
    case 'ADD_FILES':
      return { ...state, files: [...state.files, ...action.payload] };
    case 'REMOVE_FILE':
      const newFiles = state.files.filter(f => f.id !== action.payload);
      return { 
        ...state, 
        files: newFiles,
        activeFileId: state.activeFileId === action.payload ? (newFiles[0]?.id || null) : state.activeFileId 
      };
    case 'UPDATE_SETTINGS':
      return { ...state, settings: { ...state.settings, ...action.payload } };
    case 'SET_SESSION':
      return { ...state, session: action.payload };
    case 'SET_STATUS':
      return { ...state, status: action.payload };
    case 'SET_ACTIVE_FILE':
      return { ...state, activeFileId: action.payload };
    case 'RESET_APP':
      return initialState;
    default:
      return state;
  }
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Security: Cleanup on unmount
  useEffect(() => {
    return () => {
      // Revoke all blob URLs to prevent memory leaks and access
      state.files.forEach(f => {
        if (f.previewUrl) URL.revokeObjectURL(f.previewUrl);
      });
      if (state.settings.logoUrl) URL.revokeObjectURL(state.settings.logoUrl);
      clearStorage().catch(console.error);
      logger.log('app_session_end');
    };
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
